# ATM Management System using Python
## Project Report

## 1. Cover Page

**Project Title:** ATM Management System using Python

**Course:** ______________________________

**Student Name:** ________________________

**Roll Number:** _________________________

**Section:** _____________________________

**Faculty:** _____________________________

**Academic Year:** 2026–27

---

## 2. Introduction

The ATM Management System is a console-based Python project designed to demonstrate basic banking operations through a simple user interface. The application first authenticates the user using a PIN. After successful authentication, the user can check the account balance, deposit money, withdraw money, and view transaction history.

The project applies Python programming concepts such as functions, loops, conditional statements, dictionaries, lists, exception handling, and input validation.

---

## 3. Problem Statement

An ATM needs to authenticate users and provide controlled access to common account operations. The purpose of this project is to model these basic operations in a simple Python console application.

---

## 4. Objectives

- Implement PIN-based authentication.
- Limit PIN attempts to three.
- Display account balance.
- Process deposits.
- Process withdrawals.
- Prevent withdrawals exceeding the available balance.
- Record deposit and withdrawal transactions.
- Handle invalid numeric input and invalid menu choices.

---

## 5. Functional Requirements

### FR1: PIN Authentication
The system asks the user for a PIN and allows up to three attempts.

### FR2: Balance Enquiry
The system displays the current account balance.

### FR3: Deposit
The user can enter a positive amount, which is added to the balance and recorded in transaction history.

### FR4: Withdrawal
The user can enter a withdrawal amount. The system checks that the amount is positive and does not exceed the available balance.

### FR5: Transaction History
The system displays recorded deposit and withdrawal transactions.

### FR6: Exit
The user can exit the ATM menu.

---

## 6. Non-Functional Requirements

### Usability
The application provides a simple numbered console menu.

### Reliability
The application checks invalid amounts and prevents withdrawals when sufficient balance is unavailable.

### Error Handling
`try-except` blocks handle non-numeric amount input.

### Maintainability
The program uses separate functions for authentication, balance enquiry, deposit, withdrawal, history, and program control.

### Performance
The operations use simple in-memory data structures and are intended to execute quickly for the small demonstration dataset.

---

## 7. System Architecture

The system can be represented using the following logical layers:

**User**
↓
**Console Interface**
↓
**Authentication**
↓
**ATM Operations**
├── Balance
├── Deposit
├── Withdrawal
└── History
↓
**In-Memory Data**
├── PIN
├── Balance
└── Transaction History

The current implementation stores the PIN, balance, and transaction history in a Python dictionary/list structure.

---

## 8. Workflow

1. Start application.
2. Ask user for PIN.
3. Compare entered PIN with configured PIN.
4. If incorrect, reduce remaining attempts.
5. After three failed attempts, stop the application.
6. If correct, display ATM menu.
7. User selects an operation.
8. Perform the selected operation.
9. Return to the menu.
10. Exit when the user selects option 5.

---

## 9. Use Case Diagram Specification

**Actor:** User

**Use Cases:**
- Authenticate using PIN
- Check balance
- Deposit money
- Withdraw money
- View transaction history
- Exit application

For the final PDF, draw the User actor on the left and connect it to each of the six use cases.

---

## 10. Class/Component Diagram Specification

The current program is function-oriented rather than class-oriented. A component/function diagram can therefore be used.

**Components:**
- `start()`
- `checkpin()`
- `balance()`
- `deposit()`
- `withdraw()`
- `history()`
- `data` dictionary

Relationships:
- `start()` calls `checkpin()`.
- `start()` calls the operation functions according to the selected menu option.
- `deposit()` and `withdraw()` update `data`.
- `history()` reads transaction data from `data`.

---

## 11. Sequence Diagram Specification

For a normal transaction:

User → `start()` → `checkpin()` → Authentication successful

User → Menu → selects Deposit

Menu → `deposit()` → asks for amount

User → amount

`deposit()` → updates balance

`deposit()` → adds transaction to history

`deposit()` → displays updated balance

Application → Menu

The same structure can be adapted for withdrawal and balance enquiry.

---

## 12. Data/Storage Design

The current project does not use a database. It uses an in-memory Python dictionary:

```text
data
├── pin
├── balance
└── history
```

Example:

```text
pin     → "1234"
balance → 1000
history → []
```

The `history` list stores transaction descriptions.

Because this data is held in memory, it is lost when the application terminates.

---

## 13. Design Decisions and Rationale

### Dictionary for Account Data
A dictionary provides simple key-value access for the PIN, balance, and transaction history.

### List for History
A list allows transactions to be appended in chronological execution order.

### Functions
Separate functions make each ATM operation easier to understand and maintain.

### Exception Handling
`try-except ValueError` prevents the program from terminating when a user enters non-numeric amounts.

### Loop-Based Menu
A `while True` loop keeps the ATM menu active until the user selects Exit.

---

## 14. Implementation Details

The project contains the following logical functions:

- `checkpin()` — validates the PIN and controls the number of attempts.
- `balance()` — displays the current balance.
- `deposit()` — validates and adds a deposit.
- `withdraw()` — validates a withdrawal and checks available balance.
- `history()` — displays recorded transactions.
- `start()` — controls the overall application workflow.

The `time.sleep(1)` statement provides a short pause after menu operations.

---

## 15. Screenshots / Results

Add screenshots of the following outputs to the final PDF:

### Screenshot 1 — PIN Authentication
Show successful PIN entry.

### Screenshot 2 — Main Menu
Show the five ATM options.

### Screenshot 3 — Balance
Show the initial/current balance.

### Screenshot 4 — Deposit
Show a successful deposit and updated balance.

### Screenshot 5 — Withdrawal
Show a successful withdrawal and updated balance.

### Screenshot 6 — Transaction History
Show recorded deposits/withdrawals.

### Screenshot 7 — Invalid Input
Show handling of an invalid amount or invalid menu choice.

---

## 16. Testing Approach

| Test ID | Test Case | Expected Result |
|---|---|---|
| T01 | Enter correct PIN | Authentication succeeds |
| T02 | Enter wrong PIN | Remaining attempts decrease |
| T03 | Enter wrong PIN three times | Account locked message displayed |
| T04 | Select balance | Current balance displayed |
| T05 | Deposit positive amount | Balance increases |
| T06 | Deposit zero/negative amount | Amount rejected |
| T07 | Withdraw valid amount | Balance decreases |
| T08 | Withdraw more than balance | Withdrawal rejected |
| T09 | Enter text instead of amount | Invalid amount handled |
| T10 | View history | Recorded transactions displayed |
| T11 | Invalid menu choice | Invalid choice message displayed |
| T12 | Select exit | Program terminates |

---

## 17. Challenges Faced

- Designing a simple menu-driven workflow.
- Handling incorrect PIN attempts.
- Validating deposit and withdrawal amounts.
- Preventing withdrawal beyond the available balance.
- Recording transaction history.
- Handling non-numeric user input without terminating the program.

---

## 18. Learnings and Key Takeaways

The project provided practical understanding of:
- Python functions.
- Conditional statements.
- Loops.
- Dictionaries and lists.
- Exception handling.
- Input validation.
- Menu-driven programming.
- Basic software modularity.
- Designing a simple real-world problem solution.

---

## 19. Future Enhancements

Possible improvements include:
- Multiple customer accounts.
- Database integration.
- Persistent transaction history.
- Secure password/PIN hashing.
- GUI interface.
- Web-based interface.
- Automated unit tests.
- Account statements and receipt generation.
- Administrative account management.

---

## 20. References

- Python 3 documentation.
- Course material and classroom notes.
- VITyarthi Build Your Own Project submission guidelines.


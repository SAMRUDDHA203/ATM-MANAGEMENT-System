data = {
    "pin": "1234",
    "balance": 1000,
    "history": []
}

import time
from authentication import checkpin
from menu import show_menu, handle_choice

def start():
    if not checkpin():
        return

    while True:
        show_menu()
        choice = input("enter your choice : ")

        if not handle_choice(choice):
            print("Thank you")
            break

        time.sleep(1)

if __name__ == "__main__":
    start()

# Project Statement

## Project Title
ATM Management System using Python

## Problem Statement
The project aims to develop a simple console-based ATM Management System that can authenticate a user and provide basic banking operations such as balance enquiry, deposit, withdrawal, and transaction history.

## Scope of the Project
The project covers:
- PIN-based authentication.
- Balance enquiry.
- Deposit processing.
- Withdrawal processing.
- Transaction history.
- Basic input validation and error handling.

The project does not implement real banking infrastructure, real cash hardware, online transactions, or persistent customer databases.

## Target Users
The intended users are students, learners, and evaluators who want to understand how basic ATM operations can be implemented using Python programming concepts.

## High-Level Features
1. PIN authentication.
2. Balance checking.
3. Deposit.
4. Withdrawal.
5. Transaction history.
6. Invalid input and insufficient-balance handling.

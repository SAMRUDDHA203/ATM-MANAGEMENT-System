from data import data

def balance():
    print("\nBalance")
    print("your balance is $", data["balance"])

def deposit():
    try:
        amount = float(input("Enter amount : "))

        if amount > 0:
            data["balance"] += amount
            data["history"].append("Deposit : $" + str(amount))
            print("deposited")
            print("balance =", data["balance"])
        else:
            print("amount should be greater than 0")

    except ValueError:
        print("invalid amount")

def withdraw():
    try:
        amount = float(input("Enter amount to withdraw : "))

        if amount <= 0:
            print("wrong amount")
        elif amount > data["balance"]:
            print("you dont have enough money")
        else:
            data["balance"] -= amount
            data["history"].append("Withdraw : $" + str(amount))
            print("withdraw successful")
            print("balance =", data["balance"])

    except ValueError:
        print("enter number only")

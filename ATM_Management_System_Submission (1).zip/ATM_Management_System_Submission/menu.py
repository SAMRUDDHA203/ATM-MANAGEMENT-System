from account import balance, deposit, withdraw
from transactions import history

def show_menu():
    print("\n")
    print("******** ATM ********")
    print("1 balance")
    print("2 deposit")
    print("3 withdraw")
    print("4 history")
    print("5 exit")

def handle_choice(choice):
    if choice == "1":
        balance()
    elif choice == "2":
        deposit()
    elif choice == "3":
        withdraw()
    elif choice == "4":
        history()
    elif choice == "5":
        return False
    else:
        print("invalid choice")
    return True

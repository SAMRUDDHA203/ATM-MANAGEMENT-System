from data import data

def history():
    print("\nHistory")

    if len(data["history"]) == 0:
        print("nothing here")
    else:
        for transaction in data["history"]:
            print(transaction)

# ATM Management System using Python

## 1. Project Overview
The ATM Management System is a Python-based console application that simulates basic ATM operations. The system authenticates a user using a PIN and, after successful authentication, provides options to check balance, deposit money, withdraw money, and view transaction history.

## 2. Problem Statement
Traditional ATM operations involve authentication, account balance management, cash deposit/withdrawal, and transaction tracking. This project demonstrates these basic operations in a simple command-line application using Python functions, conditional statements, loops, exception handling, dictionaries, and lists.

## 3. Objectives
- Implement PIN-based user authentication.
- Provide a balance enquiry facility.
- Allow deposits and withdrawals.
- Maintain a transaction history during program execution.
- Validate invalid amounts and insufficient balance.
- Demonstrate modular programming using Python functions.

## 4. Features
- PIN verification with a maximum of three attempts.
- Account locking message after three incorrect PIN attempts.
- Balance enquiry.
- Deposit operation.
- Withdrawal operation.
- Insufficient-balance validation.
- Transaction history.
- Invalid menu-choice handling.
- Invalid numeric-input handling.

## 5. Technologies Used
- Python 3
- `time` module
- Python dictionary and list
- Console/command-line interface

## 6. Project Structure
```text
ATM-Management-System/
├── main.py
├── authentication.py
├── account.py
├── transactions.py
├── menu.py
├── data.py
├── README.md
├── statement.md
├── requirements.txt
└── screenshots/
```

## 7. How to Run
1. Install Python 3.
2. Open a terminal in the project folder.
3. Run:
   `python main.py`
4. Enter the configured PIN when prompted.
5. Select an operation from the ATM menu.

## 8. Default Test Data
- PIN: `1234`
- Initial balance: `$1000`

These values are demonstration values contained in the project code.

## 9. Testing
The following scenarios should be tested:
- Correct PIN.
- Incorrect PIN three times.
- Balance enquiry.
- Valid deposit.
- Invalid/negative deposit.
- Valid withdrawal.
- Withdrawal greater than available balance.
- Invalid/negative withdrawal.
- Transaction history.
- Invalid menu option.
- Non-numeric amount input.

## 10. Limitations
- Data is stored only in memory and is lost when the program exits.
- The project uses a single demonstration account.
- The PIN is stored directly in the source code and is not suitable for a real banking system.
- The application is console-based.

## 11. Future Enhancements
- Database-based account storage.
- Multiple user accounts.
- Secure PIN hashing.
- Persistent transaction history.
- GUI or web interface.
- Receipt generation.
- Unit tests and automated test execution.

## 12. Academic Scope
This project demonstrates programming concepts including functions, loops, conditional logic, dictionaries, lists, exception handling, input validation, and basic modular design.

from data import data

def checkpin():
    attempts = 3

    while attempts > 0:
        pin = input("Enter your pin : ")

        if pin == data["pin"]:
            print("pin correct")
            return True

        attempts -= 1
        print("wrong pin")
        print("tries left", attempts)

    print("account locked")
    return False
